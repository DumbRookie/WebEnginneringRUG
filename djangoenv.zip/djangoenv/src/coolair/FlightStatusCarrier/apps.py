from django.apps import AppConfig


class FlightstatuscarrierConfig(AppConfig):
    name = 'FlightStatusCarrier'
