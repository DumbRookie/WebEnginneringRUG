from django.db import models

# Create your models here.
class FlightStatu(models.Model):
	
	carrierCode 	  = models.TextField()
	carrierName 	  = models.TextField()
	month 			  = models.TextField()
	year			  = models.TextField()
	cancelledFlights  = models.TextField()
	onTimeFlights 	  = models.TextField()
	totalFlights	  = models.TextField()
	delayedFlights    = models.TextField()
	divertedFlights   = models.TextField()