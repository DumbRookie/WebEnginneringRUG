from django.contrib import admin

# Register your models here.
from .models import CarrierInAirport

admin.site.register(CarrierInAirport)