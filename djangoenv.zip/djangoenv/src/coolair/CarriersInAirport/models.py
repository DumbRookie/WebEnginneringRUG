from django.db import models

# Create your models here.
class CarrierInAirport(models.Model):

	carrierCode = models.TextField()
	carrierName = models.TextField()
	airportCode = models.TextField()