from django.apps import AppConfig


class CarriersinairportConfig(AppConfig):
    name = 'CarriersInAirport'
