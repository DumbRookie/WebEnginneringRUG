from django.apps import AppConfig


class StatisticscarriermonthConfig(AppConfig):
    name = 'StatisticsCarrierMonth'
