from django.db import models

# Create your models here.
class Statistic(models.Model):

	carrierCode 	  = models.TextField()
	carrierName 	  = models.TextField()
	month 			  = models.TextField()
	year			  = models.TextField()
	cancelledFlights  = models.TextField()
	onTimeFlights 	  = models.TextField()
	totalFlights	  = models.TextField()
	delayedFlights    = models.TextField()
	divertedFlights   = models.TextField()
	DelaysdueToLateAircraft = models.TextField()
	DelaysdueToWeather	  = models.TextField()
	DelaysdueToSecurity	  = models.TextField()
	DelaysdueToNAS		  = models.TextField()
	DelaysdueToCarrier	  = models.TextField()
	MinsdueToLateAircraft = models.TextField()
	MinsdueToWeather	  = models.TextField()
	MinsdueToSecurity	  = models.TextField()
	MinsdueToNAS		  = models.TextField()
	MinsdueToCarrier	  = models.TextField()


