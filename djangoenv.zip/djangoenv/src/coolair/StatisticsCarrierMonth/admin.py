from django.contrib import admin

# Register your models here.
from .models import Statistic

admin.site.register(Statistic)