from django.db import models

# Create your models here.
class Airport(models.Model):
	
	airportCode 	   = models.TextField()
	airportDescription = models.TextField()