from django.apps import AppConfig


class AllusairportsConfig(AppConfig):
    name = 'allUSAirports'
