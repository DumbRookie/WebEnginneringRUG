from django.apps import AppConfig


class MinuteofdelaycarrierConfig(AppConfig):
    name = 'MinuteOfDelayCarrier'
