from django.contrib import admin

# Register your models here.
from .models import Carrier

admin.site.register(Carrier)