from django.apps import AppConfig


class AlluscarriersConfig(AppConfig):
    name = 'allUSCarriers'
