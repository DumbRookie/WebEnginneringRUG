from django.db import models

# Create your models here.
class Carrier(models.Model):
	
	carrierCode		= models.TextField()
	carrierName		= models.TextField()